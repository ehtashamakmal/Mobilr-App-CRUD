package com.example.service1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Next_Page extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_next_page);
    }
}