package com.example.testingapp;

public class ObjectStudent {


    int id;
    String firstname;
    String email;
    public ObjectStudent(){
    }
}
