package com.example.imagetesting;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Register extends AppCompatActivity {

    EditText edUsername, edEmail, edPassword, edCPassword;
    Button btn;
    TextView tv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        edUsername = findViewById(R.id.editTextFullName);
        edEmail = findViewById(R.id.editTextEmail);
        edPassword = findViewById(R.id.editTextRegPassword);
        edCPassword = findViewById(R.id.editTextRegCPassword);
        btn = findViewById(R.id.button);
        tv = findViewById(R.id.textViewTCCBM);

        tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username = edUsername.getText().toString();
                String password = edPassword.getText().toString();
                String Email = edEmail.getText().toString();
                String confirm = edCPassword.getText().toString();
                DataBase db = new DataBase(getApplicationContext(), "healthcare", null,1);

                if (username.length() == 0 || password.length() == 0 || confirm.length() == 0 || Email.length() == 0) {
                    Toast.makeText(getApplicationContext(), "Please Fill all the details", Toast.LENGTH_LONG).show();
                } else {

                    if (password.compareTo(confirm) == 0) {
                             if(isValid(password)){
                             db.register(username, Email,password);


                                 Toast.makeText(getApplicationContext(), "Record Inserted", Toast.LENGTH_LONG).show();
                                 startActivity(new Intent(Register.this, LoginActivity.class));
                             }
                             else {
                                 Toast.makeText(getApplicationContext(), "Password must contain al least 8 characters, having letter, digit and special symbol", Toast.LENGTH_LONG).show();
                             }

                    } else {
                        Toast.makeText(getApplicationContext(), "Password and Confirm password are not same", Toast.LENGTH_LONG).show();
                    }

                }


            }
        });
    }

    public static boolean isValid(String passwordhere) {

        int f1 = 0, f2 = 0, f3 = 0;
        if (passwordhere.length() < 8) {

            return false;
        }
        else {
            for (int p = 0; p < passwordhere.length(); p++) {


                if (Character.isLetter(passwordhere.charAt(p))) {

                    f1 = 1;
                }

            }
            for (int r = 0; r < passwordhere.length(); r++) {


                if (Character.isLetter(passwordhere.charAt(r))) {

                    f2 = 1;
                }


            }
            for (int s = 0; s < passwordhere.length(); s++) {


                if (Character.isLetter(passwordhere.charAt(s))) {

                    f3 = 1;
                }
            }

            if (f1 == 1 && f2 == 1 && f3 == 1)
                return true;
            return false;

        }
    }
}

