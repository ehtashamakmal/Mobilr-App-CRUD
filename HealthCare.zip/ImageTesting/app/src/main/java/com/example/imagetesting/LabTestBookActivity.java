package com.example.imagetesting;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LabTestBookActivity extends AppCompatActivity {


    EditText ed1,ed2,ed3,ed4;
    Button btnBook;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab_test_book);

        ed1 = findViewById(R.id.editTextFullName);
        ed2=findViewById(R.id.editTextAddress);
        ed3=findViewById(R.id.editTextContact);
        ed4=findViewById(R.id.editTextPinCode);
        btnBook=findViewById(R.id.btnbook);

        Intent intent = getIntent();
        String[] price = intent.getStringExtra("price").toString().split(java.util.regex.Pattern.quote(":"));
        String date = intent.getStringExtra("date");
        String time=intent.getStringExtra("time");


        btnBook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                SharedPreferences sharedPreferences = getSharedPreferences("shared_prefs", Context.MODE_PRIVATE);
                String username = sharedPreferences.getString("username","").toString();

                DataBase db = new DataBase(getApplicationContext(),"healthcare",null,1);
                db.addOrder(username,ed1.getText().toString(),ed2.getText().toString(),ed3.getText().toString(),Integer.parseInt(ed4.getText().toString()),date.toString(),time.toString(),Float.parseFloat(price[1].toString()),"lab");
                db.RemoveCart(username,"lab");
                Toast.makeText(getApplicationContext(), "Your Booking is done successfully", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(LabTestBookActivity.this,HomeActivity.class));



            }
        });
    }
}